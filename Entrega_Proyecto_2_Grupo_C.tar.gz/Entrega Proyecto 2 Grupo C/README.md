# Proyecto 1 Sistemas Operativos

``Pasos para ejecutar``
1. $ makefile (sirve para compilar automaticamente los dos archivos c).
   
2. $ ./controlador –i 7 –f 19 –s 1 –t 10 –p pipecrecibe (Corre el servidor)(es un ejemplo para realizar las pruebas).
   
3. $ ./agente –s agentazo –a ejemplo.txt –p pipecrecibe (Corre el agente)(es un ejemplo para realizar las pruebas).

